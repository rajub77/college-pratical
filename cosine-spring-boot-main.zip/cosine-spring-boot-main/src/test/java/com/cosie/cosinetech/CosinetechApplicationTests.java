package com.cosie.cosinetech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CosinetechApplicationTests {

	@Test
	void contextLoads() {
	}

}
