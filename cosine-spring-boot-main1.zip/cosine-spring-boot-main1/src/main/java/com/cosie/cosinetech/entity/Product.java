package com.cosie.cosinetech.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Column;

@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "product_id", nullable = false) // Change "id" to "product_id"
    private Long price;

    @Column(name = "product_name") // Change "name" to "product_name"
    private String name;

    @Column(name = "product_description") // Change "description" to "product_description"
    private String description;
}
