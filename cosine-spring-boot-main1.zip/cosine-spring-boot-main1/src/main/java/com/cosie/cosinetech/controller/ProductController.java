package com.cosie.cosinetech.controller;

import com.cosie.cosinetech.entity.Product;
import com.cosie.cosinetech.repository.ProductRepository; // Correct import statement
import org.springframework.beans.factory.annotation.Autowired; // Correct @Autowired annotation
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class ProductController {

    @Autowired
    ProductRepository productRepository; // Correct repository name

    @GetMapping("name")
    public ResponseEntity<Integer> getName() {
        return ResponseEntity.ok(12882);
    }

    @PostMapping("/add")
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        Product savedProduct = productRepository.save(product); // Use the correct repository for saving
        return ResponseEntity.ok(savedProduct);
    }
}
